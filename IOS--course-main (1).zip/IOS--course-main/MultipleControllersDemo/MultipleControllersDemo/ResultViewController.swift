//
//  ResultViewController.swift
//  MultipleControllersDemo
//
//  Created by student on 10/19/21.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var EnterAmount: UILabel!
    
    @IBOutlet weak var disRateOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
