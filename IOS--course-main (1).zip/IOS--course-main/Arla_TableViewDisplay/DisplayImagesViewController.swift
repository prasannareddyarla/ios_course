//
//  DisplayImagesViewController.swift
//  Arla_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class DisplayImagesViewController: UICollectionViewCell {
    
}
